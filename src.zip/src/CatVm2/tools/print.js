catvm.print = {}
catvm.memory.print = []
catvm.print.log = function(){

}
catvm.print.getall = function(){
    
}