global.catvm ={}
catvm.memory ={
    config:{ print : false , proxy : false },
}
catvm.memory.htmlElements ={

}
catvm.memory.listeners ={}
catvm.memory.PluginArray = {}
