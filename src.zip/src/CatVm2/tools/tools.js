//更改浏览器某些参数

catvm.AddPlugin = function(data){

}